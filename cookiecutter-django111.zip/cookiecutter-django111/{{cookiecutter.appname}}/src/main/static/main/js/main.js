class HelloWorld {
  constructor() {
    console.log('Hello, World!')
  }
}
new HelloWorld()
